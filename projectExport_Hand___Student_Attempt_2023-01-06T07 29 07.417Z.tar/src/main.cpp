///4
#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
//#include <unordered_map>
#include <tuple>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Delaunay_triangulation_2.h>
#include <CGAL/Triangulation_vertex_base_with_info_2.h>
#include <CGAL/Triangulation_face_base_2.h>
#include <boost/graph/adjacency_list.hpp>
#include <boost/pending/disjoint_sets.hpp>

typedef boost::adjacency_list<boost::vecS, 
                              boost::vecS, 
                              boost::undirectedS> graph;
typedef boost::graph_traits<graph>::edge_descriptor edge_desc;
typedef int Index;
typedef CGAL::Exact_predicates_inexact_constructions_kernel K;
typedef K::Point_2                                             P;
typedef CGAL::Triangulation_vertex_base_with_info_2<int,K> Vb;
typedef CGAL::Triangulation_face_base_2<K> Fb;
typedef CGAL::Triangulation_data_structure_2<Vb,Fb> Tds;
typedef CGAL::Delaunay_triangulation_2<K,Tds>                  Delaunay;
typedef std::tuple<int,int,K::FT> Edge;
typedef std::vector<Edge> EdgeV;

int get_greedy(std::vector<int>& num, int k){
  int num1 = num[1]; 
  int num2 = num[2]; 
  int num3 = num[3];
  if(k == 1)         return num1+num2+num3;
  if(k == 2)         return num1/2+num2+num3;
  if(k == 3) {
    if(num1 <= num2) return num1 + (num2 - num1)/2 + num3;
    else             return num2 + (num1 - num2)/3 + num3;
  }
  if(k == 4){
    if(num1 <= num3) return num1 + (num3 - num1 + num2)/2;
     else            return num3 + ((num1 - num3)/2 + num2)/2;
  }
  return -1;
}

void solve(){
  int n,k,f;
  long s;
  std::cin >> n >> k >> f >> s;
  
  std::vector<int> m(n,1);
  std::vector<std::pair<P, int>> tents(n);
  for(int i = 0; i < n; i++){
    int x,y;
    std::cin >> x >> y;
    tents[i] = {P(x,y), i};
  }
  
  Delaunay t;
  t.insert(tents.begin(), tents.end());
  
  // extract edges and sort by (squared) length
  // This step takes O(n log n) time (for the sorting).
  EdgeV edges;
  edges.reserve(3*n); // there can be no more in a planar graph
  
  for (auto e = t.finite_edges_begin(); e != t.finite_edges_end(); ++e) {
    Index i1 = e->first->vertex((e->second+1)%3)->info();
    Index i2 = e->first->vertex((e->second+2)%3)->info();
    // ensure smaller index comes first
    if (i1 > i2) std::swap(i1, i2);
    edges.emplace_back(i1, i2, t.segment(e).squared_length());
  }
  std::sort(edges.begin(), edges.end(),
      [](const Edge& e1, const Edge& e2) -> bool {
        return std::get<2>(e1) < std::get<2>(e2);
            });
  
  // setup and initialize union-find data structure
  boost::disjoint_sets_with_storage<> uf(n);
  Index n_components = n;
  int resf = 1;
  K::FT ress = 0;
  std::vector<int> num = {0, n, 0, 0, 0};
  
  // ... and process edges in order of increasing length
  for(EdgeV::const_iterator e = edges.begin(); e != edges.end(); ++e) {
    // determine components of endpoints
    Index c1 = uf.find_set(std::get<0>(*e));
    Index c2 = uf.find_set(std::get<1>(*e));
    
    auto dist = std::get<2>(*e);
    int curr_f = num[4] + get_greedy(num, k);
    if(dist >= s){
      resf = std::max(resf, curr_f);
    }
    if (curr_f >= f){
      ress = std::max(dist, ress);
    }
    
    if (c1 != c2) {
      n_components--;
      uf.link(c1, c2);
      Index new_c = uf.find_set(std::get<0>(*e));
      int m1 = m[c1], m2 = m[c2];
      m[new_c] = m[c1] + m[c2];
      num[ std::min(m1, 4) ]--;
      num[ std::min(m2, 4) ]--;
      num[ std::min(m[new_c], 4) ]++;
    }
  }
  std::cout << (long)CGAL::to_double(ress) << ' '  << resf << '\n';
}

int main(){
  std::ios_base::sync_with_stdio(false);
  std::cin.tie(NULL);
  
  int t;
  std::cin >> t;
  while(t--)solve();
  return 0;
}